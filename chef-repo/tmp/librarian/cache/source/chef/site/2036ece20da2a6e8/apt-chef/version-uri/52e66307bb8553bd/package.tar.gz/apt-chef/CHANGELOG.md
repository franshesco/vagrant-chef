apt-chef Cookbook CHANGELOG
===========================

This file is used to list changes made in each version of the apt-chef cookbook.

# v0.2.0

- [#1](https://github.com/chef-cookbooks/apt-chef/pull/1) Add stable and current recipes
